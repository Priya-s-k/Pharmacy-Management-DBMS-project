-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2021 at 04:35 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sales`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetCustomers` ()  NO SQL
BEGIN
SELECT * FROM customer ORDER BY customer_id DESC;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `collection`
--

CREATE TABLE `collection` (
  `transaction_id` int(11) NOT NULL,
  `date` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `balance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `membership_number` varchar(100) NOT NULL,
  `prod_name` varchar(550) NOT NULL,
  `expected_date` varchar(500) NOT NULL,
  `note` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `address`, `contact`, `membership_number`, `prod_name`, `expected_date`, `note`) VALUES
(15, 'sfd', 'dfhj', '5464', '12', 'hgvj', '2019-11-07', 'hgvjbj'),
(16, 'Gururaj', 'chitradurga', '9856253625', '15', 'cipla...', '2019-11-30', 'cold...\r\n'),
(17, 'Vinod kumar', 'Gulbarga', '8451278965', '10', 'vicks', '2019-12-28', 'headache patient'),
(18, 'netra', 'karwar', '8861916626', '10', 'cipla', '2019-12-13', 'cold'),
(19, 'Shrinivasa', 'Udupi', '5486543165', '658', '.kdnwifkjwm;lmdsoijcknds kcl;djk9ijkdsm, ,á¹‡bdsucdscdskncjoijdcd', '2021-11-25', 'dkjcbhukp\r\nfu');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `gen_name` varchar(200) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `cost` varchar(100) NOT NULL,
  `o_price` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `profit` varchar(100) NOT NULL,
  `supplier` varchar(100) NOT NULL,
  `onhand_qty` int(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `qty_sold` int(10) NOT NULL,
  `expiry_date` varchar(500) NOT NULL,
  `date_arrival` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_code`, `gen_name`, `product_name`, `cost`, `o_price`, `price`, `profit`, `supplier`, `onhand_qty`, `qty`, `qty_sold`, `expiry_date`, `date_arrival`) VALUES
(59, 'Cipla', 'Common Cold', ' Cold ', '', '12', '15', '3', 'fr', 0, 50, 50, '2019-11-29', '2019-10-03'),
(67, 'ish', 'calsium', 'vitamins  ', '', '10', '15', '5', 'Pranav L M', 0, 500, 500, '2021-05-15', '2019-12-09'),
(68, 'njk', 'abc', ' yeye  ', '', '100', '158', '58', 'Pranav L M', 0, 200, 200, '2019-12-18', '2019-12-04'),
(69, 'cipla2', 'dfsdf', ' fsfdf ', '', '12', '20', '8', 'Priyanka', 0, 10, 10, '2020-02-14', '2020-02-05');

--
-- Triggers `products`
--
DELIMITER $$
CREATE TRIGGER `logger` AFTER INSERT ON `products` FOR EACH ROW INSERT INTO `product_log` (`name`, `time`) VALUES ((SELECT product_code FROM `products` ORDER by product_id desc LIMIT 1), current_timestamp())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `product_log`
--

CREATE TABLE `product_log` (
  `name` varchar(50) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_log`
--

INSERT INTO `product_log` (`name`, `time`) VALUES
('w2', '2019-11-16 17:10:29'),
('ITC', '2019-11-19 14:57:10'),
('g', '2019-11-20 15:38:34'),
('q', '2019-11-20 16:05:51'),
('t', '2019-11-30 05:56:23'),
('Uniliever', '2019-12-09 07:05:16'),
('gsk', '2019-12-10 13:03:53'),
('njk', '2019-12-11 09:13:18'),
('dfdf', '2020-02-22 15:55:37'),
('lk;wrefrf', '2020-10-05 16:29:53');

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `transaction_id` int(11) NOT NULL,
  `invoice_number` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `suplier` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `purchases_item`
--

CREATE TABLE `purchases_item` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `cost` varchar(100) NOT NULL,
  `invoice` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `transaction_id` int(11) NOT NULL,
  `invoice_number` varchar(100) NOT NULL,
  `cashier` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `profit` varchar(100) NOT NULL,
  `due_date` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `balance` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`transaction_id`, `invoice_number`, `cashier`, `date`, `type`, `amount`, `profit`, `due_date`, `name`, `balance`) VALUES
(142, 'RS-32333', 'Admin', '11/14/19', 'cash', '158', '38', '160', 'po', ''),
(143, 'RS-2533', 'Admin', '11/19/19', 'cash', '1004', '152', '1100', 'Priyanka', ''),
(144, 'RS-52', 'Admin', '11/19/19', 'cash', '158', '38', '120', 'jhgf', ''),
(145, 'RS-39325773', 'Admin', '11/21/19', 'cash', '534', '70', '550', 'yfh', ''),
(146, 'RS-9305249', 'Admin', '11/21/19', 'cash', '616', '24', '650', 'Koli', ''),
(147, 'RS-630688', 'Admin', '11/28/19', 'cash', '390', '28', '500', 'Diwakar', ''),
(148, 'RS-300623', 'Admin', '11/28/19', 'cash', '534', '70', '600', 'HGF', ''),
(149, 'RS-3322046', 'Admin', '11/28/19', 'cash', '1684', '164', '1800', 'HYTRDE', ''),
(150, 'RS-02050225', 'Admin', '11/28/19', 'cash', '534', '70', '550', 'HGFDE', ''),
(151, 'RS-239383', 'Admin', '11/28/19', 'cash', '534', '70', '550', 'KJHGF', ''),
(152, 'RS-2230204', 'Admin', '11/28/19', 'cash', '154', '6', '200', 'HGFDS', ''),
(153, 'RS-2432034', 'Admin', '11/28/19', 'cash', '154', '6', '200', 'JBH', ''),
(154, 'RS-02000753', 'Admin', '11/29/19', 'cash', '308', '12', '500', 'dfg', ''),
(155, 'RS-335023', 'Admin', '11/30/19', 'cash', '308', '12', '400', 'jh', ''),
(156, 'RS-2222004', 'Admin', '11/30/19', 'cash', '4106', '426', '1500', 'vignesha', ''),
(157, 'RS-62223', 'Admin', '11/30/19', 'cash', '10680', '1400', '11000', 'gfdfgh', ''),
(158, 'RS-33322', 'Admin', '12/08/19', 'cash', '600', '50', '1000', 'gfd', ''),
(159, 'RS-20038', 'Admin', '12/08/19', 'cash', '720', '60', '800', 'kjh', ''),
(160, 'RS-33927303', 'Admin', '12/09/19', 'cash', '2136', '280', '2200', 'ffvcd', ''),
(161, 'RS-0203222', 'Admin', '12/10/19', 'cash', '5874', '770', '6000', 'pranav', ''),
(162, 'RS-63373722', 'Admin', '12/10/19', 'cash', '1580', '380', '2000', 'irfan', ''),
(163, 'RS-33733238', 'Admin', '12/10/19', 'cash', '75', '25', '100', 'brunda', ''),
(164, 'RS-29030200', 'Admin', '12/10/19', 'cash', '150', '30', '200', 'pd', ''),
(165, 'RS-70838320', 'Admin', '12/11/19', 'cash', '30', '6', '50', 'preethi', ''),
(166, 'RS-236275', 'Admin', '12/11/19', 'cash', '400', '50', '500', 'pl', ''),
(167, 'RS-23290303', 'Admin', '12/18/19', 'cash', '45', '15', '50', 'pkkk', ''),
(168, 'RS-23290303', 'Admin', '12/18/19', 'cash', '45', '15', '50', 'pkkk', ''),
(169, 'RS-37232249', 'Admin', '01/18/20', 'cash', '280', '35', '300', '', ''),
(170, 'RS-52723', 'Admin', '02/18/20', 'cash', '300', '60', '500', '', ''),
(171, 'RS-3622062', 'Admin', '02/22/20', 'cash', '440', '55', '500', 'sneha', ''),
(172, 'RS-3623220', 'Admin', '04/03/20', 'cash', '50', '18', '100', '', ''),
(173, 'RS-70933', 'Admin', '04/11/20', 'cash', '350', '130', '500', 'gky', ''),
(174, 'RS-273037', 'Admin', '10/05/20', 'cash', '110', '42', '150', 'nachi', ''),
(175, 'RS-332202', 'Admin', '10/05/20', 'cash', '732', '272', '800', 'Amit', ''),
(176, 'RS-53023234', 'Admin', '10/23/20', 'cash', '820', '296', '1000', '', ''),
(177, 'RS-9032322', 'Admin', '10/29/20', 'cash', '75', '25', '100', 'Swapna', ''),
(178, 'RS-4325333', 'Admin', '11/03/20', 'cash', '45', '15', '50', 'chinny', ''),
(179, 'RS-222222', 'Admin', '11/05/20', 'cash', '970', '350', '1000', 'raveen', ''),
(180, 'RS-3332', 'Admin', '12/18/20', 'cash', '30', '10', '100', 'vvvv', ''),
(181, 'RS-0082233', 'Admin', '12/29/20', 'cash', '120', '44', '150', '', ''),
(182, 'RS-3370233', 'Admin', '01/09/21', 'cash', '1580', '580', '2000', 'naveev', ''),
(183, 'RS-25303203', 'Admin', '01/11/21', 'cash', '15', '3', '15', 'abs', ''),
(184, 'RS-40350303', 'Admin', '01/11/21', 'cash', '150', '50', '200', '', ''),
(185, 'RS-24332', 'Admin', '01/11/21', 'cash', '1580', '580', '100', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `sales_order`
--

CREATE TABLE `sales_order` (
  `transaction_id` int(11) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `product` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `profit` varchar(100) NOT NULL,
  `product_code` varchar(150) NOT NULL,
  `gen_name` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `price` varchar(100) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `date` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supliers`
--

CREATE TABLE `supliers` (
  `suplier_id` int(11) NOT NULL,
  `suplier_name` varchar(100) NOT NULL,
  `suplier_address` varchar(100) NOT NULL,
  `suplier_contact` varchar(100) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `note` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supliers`
--

INSERT INTO `supliers` (`suplier_id`, `suplier_name`, `suplier_address`, `suplier_contact`, `contact_person`, `note`) VALUES
(9, 'Pranav L M', 'chitradurga', 'hr.', '8197884562', 'good.'),
(10, 'Priyanka', 'belgam', 'GM', '9380418706', 'goods '),
(12, 'Ravi kumar', 'Mangalore', 'medical rep.', '8457956235', 'good product'),
(14, 'vishal nayak', 'Banglore', '5486543165', '564325335663', 'gfg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `name`, `position`) VALUES
(1, 'admin', 'admin', 'Admin', 'admin'),
(2, 'cashier', 'cashier', 'Cashier Pharmacy', 'Cashier'),
(3, 'admin', 'admin123', 'Administrator', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `collection`
--
ALTER TABLE `collection`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `purchases_item`
--
ALTER TABLE `purchases_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `sales_order`
--
ALTER TABLE `sales_order`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `supliers`
--
ALTER TABLE `supliers`
  ADD PRIMARY KEY (`suplier_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `collection`
--
ALTER TABLE `collection`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `purchases_item`
--
ALTER TABLE `purchases_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=186;

--
-- AUTO_INCREMENT for table `sales_order`
--
ALTER TABLE `sales_order`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supliers`
--
ALTER TABLE `supliers`
  MODIFY `suplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
